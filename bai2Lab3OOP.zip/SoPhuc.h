#ifndef SOPHUC_H
#define SOPHUC_H

#include <bits/stdc++.h>

class SoPhuc {
private:
    double dThuc; 
    double dAo;   

public:
    SoPhuc();

    SoPhuc(double thuc, double ao);


    SoPhuc operator+(const SoPhuc& sp) const;


    SoPhuc operator-(const SoPhuc& sp) const;


    SoPhuc operator*(const SoPhuc& sp) const;


    SoPhuc operator/(const SoPhuc& sp) const;


    bool operator==(const SoPhuc& sp) const;


    bool operator!=(const SoPhuc& sp) const;


    friend std::istream& operator>>(std::istream& is, SoPhuc& sp);


    friend std::ostream& operator<<(std::ostream& os, const SoPhuc& sp);
};

#endif

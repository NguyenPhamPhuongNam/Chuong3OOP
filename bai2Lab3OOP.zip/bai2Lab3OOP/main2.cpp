#include <bits/stdc++.h>
#include "SoPhuc.h"

int main() {
    SoPhuc sp1, sp2;

    std::cout << "Nhap so phuc thu nhat: " << '\n';
    std::cin >> sp1;
    std::cout << "Nhap so phuc thu hai: " << '\n';
    std::cin >> sp2;

    std::cout << "Tong: " << (sp1 + sp2) << '\n';

    std::cout << "Hieu: " << (sp1 - sp2) << '\n';

    std::cout << "Tich: " << (sp1 * sp2) << '\n';

    std::cout << "Thuong: " << (sp1 / sp2) << '\n';

    if (sp1 == sp2) {
        std::cout << "Hai so phuc bang nhau" << '\n';
    } else {
        std::cout << "Hai so phuc khong bang nhau" << '\n';
    }

    exit(0);
}

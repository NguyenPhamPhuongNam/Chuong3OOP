#include "SoPhuc.h"
#include <bits/stdc++.h>

SoPhuc::SoPhuc() : dThuc(0), dAo(0) {}


SoPhuc::SoPhuc(double thuc, double ao) : dThuc(thuc), dAo(ao) {}


SoPhuc SoPhuc::operator+(const SoPhuc& sp) const {
    return SoPhuc(dThuc + sp.dThuc, dAo + sp.dAo);
}


SoPhuc SoPhuc::operator-(const SoPhuc& sp) const {
    return SoPhuc(dThuc - sp.dThuc, dAo - sp.dAo);
}


SoPhuc SoPhuc::operator*(const SoPhuc& sp) const {
    double thuc = dThuc * sp.dThuc - dAo * sp.dAo;
    double ao = dThuc * sp.dAo + dAo * sp.dThuc;
    return SoPhuc(thuc, ao);
}


SoPhuc SoPhuc::operator/(const SoPhuc& sp) const {
    double mau = sp.dThuc * sp.dThuc + sp.dAo * sp.dAo;
    double thuc = (dThuc * sp.dThuc + dAo * sp.dAo) / mau;
    double ao = (dAo * sp.dThuc - dThuc * sp.dAo) / mau;
    return SoPhuc(thuc, ao);
}


bool SoPhuc::operator==(const SoPhuc& sp) const {
    return (dThuc == sp.dThuc) && (dAo == sp.dAo);
}


bool SoPhuc::operator!=(const SoPhuc& sp) const {
    return !(*this == sp);
}


std::istream& operator>>(std::istream& is, SoPhuc& sp) {
    std::cout << "Nhap phan thuc: ";
    is >> sp.dThuc;
    std::cout << "Nhap phan ao: ";
    is >> sp.dAo;
    return is;
}


std::ostream& operator<<(std::ostream& os, const SoPhuc& sp) {
    os << sp.dThuc << " + " << sp.dAo << "i";
    return os;
}

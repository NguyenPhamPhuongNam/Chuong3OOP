#include "ThoiGian.h"
#include <bits/stdc++.h>


ThoiGian::ThoiGian() : iGio(0), iPhut(0), iGiay(0) {}


ThoiGian::ThoiGian(int Gio, int Phut, int Giay) : iGio(Gio), iPhut(Phut), iGiay(Giay) {}


int ThoiGian::TinhGiay() const {
    return iGio * 3600 + iPhut * 60 + iGiay;
}


void ThoiGian::TinhLaiGio(int TongGiay) {
    iGio = TongGiay / 3600;
    TongGiay %= 3600;
    iPhut = TongGiay / 60;
    iGiay = TongGiay % 60;
}

ThoiGian ThoiGian::operator+(int Giay) const {
    int TongGiay = TinhGiay() + Giay;
    ThoiGian tg;
    tg.TinhLaiGio(TongGiay);
    return tg;
}


ThoiGian ThoiGian::operator-(int Giay) const {
    int TongGiay = TinhGiay() - Giay;
    ThoiGian tg;
    tg.TinhLaiGio(TongGiay);
    return tg;
}


ThoiGian ThoiGian::operator+(const ThoiGian& tg) const {
    int TongGiay = TinhGiay() + tg.TinhGiay();
    ThoiGian ketQua;
    ketQua.TinhLaiGio(TongGiay);
    return ketQua;
}


ThoiGian ThoiGian::operator-(const ThoiGian& tg) const {
    int TongGiay = TinhGiay() - tg.TinhGiay();
    ThoiGian ketQua;
    ketQua.TinhLaiGio(TongGiay);
    return ketQua;
}

ThoiGian& ThoiGian::operator++() {
    *this = *this + 1;
    return *this;
}


ThoiGian ThoiGian::operator++(int) {
    ThoiGian temp = *this;
    ++(*this);
    return temp;
}

ThoiGian& ThoiGian::operator--() {
    *this = *this - 1;
    return *this;
}

ThoiGian ThoiGian::operator--(int) {
    ThoiGian temp = *this;
    --(*this);
    return temp;
}


bool ThoiGian::operator==(const ThoiGian& tg) const {
    return TinhGiay() == tg.TinhGiay();
}


bool ThoiGian::operator!=(const ThoiGian& tg) const {
    return !(*this == tg);
}


bool ThoiGian::operator>=(const ThoiGian& tg) const {
    return TinhGiay() >= tg.TinhGiay();
}


bool ThoiGian::operator<=(const ThoiGian& tg) const {
    return TinhGiay() <= tg.TinhGiay();
}


bool ThoiGian::operator>(const ThoiGian& tg) const {
    return TinhGiay() > tg.TinhGiay();
}


bool ThoiGian::operator<(const ThoiGian& tg) const {
    return TinhGiay() < tg.TinhGiay();
}


std::istream& operator>>(std::istream& is, ThoiGian& tg) {
    std::cout << "Nhap gio: ";
    is >> tg.iGio;
    std::cout << "Nhap phut: ";
    is >> tg.iPhut;
    std::cout << "Nhap giay : ";
    is >> tg.iGiay;
    return is;
}


std::ostream& operator<<(std::ostream& os, const ThoiGian& tg) {
    os << tg.iGio << " gio, " << tg.iPhut << " phut, " << tg.iGiay << " giay";
    return os;
}

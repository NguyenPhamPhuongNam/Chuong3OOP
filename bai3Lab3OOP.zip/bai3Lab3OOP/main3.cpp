#include <bits/stdc++.h>
#include "ThoiGian.h"

int main() {
    ThoiGian tg1, tg2;


    std::cout << "Nhap thoi gian thu nhat:" << '\n';
    std::cin >> tg1;
    std::cout << "Nhap thoi gian thu hai:" << '\n';
    std::cin >> tg2;


    std::cout << "Thoi gian thu nhat: " << tg1 << '\n';
    std::cout << "Thoi gian thu hai: " << tg2 << '\n';


    ThoiGian tong = tg1 + tg2;
    std::cout << "Tong hai thoi gian: " << tong << '\n';

    ThoiGian hieu = tg1 - tg2;
    std::cout << "Hieu hai thoi gian: " << hieu << '\n';
 
    std::cout << "Thoi gian thu nhat sau khi cong them 1 gio: " << tg1+3600 << '\n';

    std::cout << "Thoi gian thu hai sau khi tru mot phut: " << tg2-60 << '\n';

    if (tg1 == tg2) std::cout << "Hai thoi gian bang nhau." << '\n';
    if (tg1 != tg2) std::cout << "Hai thoi gian khong bang nhau." << '\n';
    if (tg1 > tg2) {
        std::cout << "Thoi gian thu nhat lon hon thoi gian thu hai."<<'\n';
    }
    else{
    std::cout << "Thoi gian thu hai lon hon thoi gian thu nhat."<<'\n';
    }
    exit(0);
}
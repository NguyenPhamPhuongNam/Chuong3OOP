#ifndef THOIGIAN_H
#define THOIGIAN_H

#include <bits/stdc++.h>

class ThoiGian {
private:
    int iGio;
    int iPhut;
    int iGiay;

public:

    ThoiGian();

    ThoiGian(int Gio, int Phut, int Giay);

    int TinhGiay() const;

    void TinhLaiGio(int Giay);


    ThoiGian operator+(int Giay) const;

    ThoiGian operator-(int Giay) const;


    ThoiGian operator+(const ThoiGian& tg) const;


    ThoiGian operator-(const ThoiGian& tg) const;

    ThoiGian& operator++();  // Tien to
    ThoiGian operator++(int); // Hau to


    ThoiGian& operator--();  // Tien to
    ThoiGian operator--(int); // Hau to


    bool operator==(const ThoiGian& tg) const;


    bool operator!=(const ThoiGian& tg) const;


    bool operator>=(const ThoiGian& tg) const;


    bool operator<=(const ThoiGian& tg) const;


    bool operator>(const ThoiGian& tg) const;


    bool operator<(const ThoiGian& tg) const;


    friend std::istream& operator>>(std::istream& is, ThoiGian& tg);
    friend std::ostream& operator<<(std::ostream& os, const ThoiGian& tg);
};

#endif

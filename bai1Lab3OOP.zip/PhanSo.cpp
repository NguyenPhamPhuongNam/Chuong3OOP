#include "PhanSo.h"
#include <bits/stdc++.h>

using namespace std;

PhanSo::PhanSo() : iTu(0), iMau(1) {}

PhanSo::PhanSo(int Tu, int Mau) {
    if (Mau == 0) {
        cout << "Mau khong the bang 0" << endl;
        exit(1);
    }
    iTu = Tu;
    iMau = Mau;
    rutgon();
}

void PhanSo::rutgon() {
    int uocchung = gcd(abs(iTu), abs(iMau));
    iTu /= uocchung;
    iMau /= uocchung;
    if (iMau < 0) { // Đảm bảo mẫu dương
        iTu = -iTu;
        iMau = -iMau;
    }
}

PhanSo PhanSo::operator+(const PhanSo& other) const {
    int newTu = iTu * other.iMau + iMau * other.iTu;
    int newMau = iMau * other.iMau;
    PhanSo result(newTu, newMau);
    return result;
}

PhanSo PhanSo::operator-(const PhanSo& other) const {
    int newTu = iTu * other.iMau - iMau * other.iTu;
    int newMau = iMau * other.iMau;
    PhanSo result(newTu, newMau);
    return result;
}

PhanSo PhanSo::operator*(const PhanSo& other) const {
    int newTu = iTu * other.iTu;
    int newMau = iMau * other.iMau;
    PhanSo result(newTu, newMau);
    return result;
}

PhanSo PhanSo::operator/(const PhanSo& other) const {
    if (other.iTu == 0) {
        cout << "Khong the chia cho phan so co tu bang 0" << endl;
        exit(1);
    }
    int newTu = iTu * other.iMau;
    int newMau = iMau * other.iTu;
    PhanSo result(newTu, newMau);
    return result;
}

bool PhanSo::operator==(const PhanSo& other) const {
    return (iTu == other.iTu && iMau == other.iMau);
}

bool PhanSo::operator!=(const PhanSo& other) const {
    return !(*this == other);
}

bool PhanSo::operator>=(const PhanSo& other) const {
    return (iTu * other.iMau >= iMau * other.iTu);
}

bool PhanSo::operator<=(const PhanSo& other) const {
    return (iTu * other.iMau <= iMau * other.iTu);
}

bool PhanSo::operator>(const PhanSo& other) const {
    return (iTu * other.iMau > iMau * other.iTu);
}

bool PhanSo::operator<(const PhanSo& other) const {
    return (iTu * other.iMau < iMau * other.iTu);
}

std::istream& operator>>(std::istream& is, PhanSo& ps) {
    std::cout << "Nhap tu so: ";
    is >> ps.iTu;
    std::cout << "Nhap mau so: ";
    is >> ps.iMau;
    if (ps.iMau == 0) {
        std::cout << "Mau khong the bang 0" << endl;
        exit(1);
    }
    ps.rutgon();
    return is;
}

std::ostream& operator<<(std::ostream& os, const PhanSo& ps) {
    if (ps.iMau == 1) {
        os << ps.iTu;
    } else {
        os << ps.iTu << "/" << ps.iMau;
    }
    return os;
}

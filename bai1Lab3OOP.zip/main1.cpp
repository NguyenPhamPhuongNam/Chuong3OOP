#include "PhanSo.h"
#include <bits/stdc++.h>

using namespace std;

int main() {
    PhanSo ps1, ps2;

    std::cout << "Nhap phan so thu nhat: " << '\n';
    std::cin >> ps1;
    std::cout << "Nhap phan so thu hai: " << '\n';
    std::cin >> ps2;

    std::cout << "Tong: " << (ps1 + ps2) << '\n';

    std::cout << "Hieu: " << (ps1 - ps2) << '\n';

    std::cout << "Tich: " << (ps1 * ps2) << '\n';

    std::cout << "Thuong: " << (ps1 / ps2) << '\n';

    if (ps1 == ps2) {
        std::cout << "Hai phan so bang nhau" << '\n';
    } else {
        std::cout << "Hai phan so khong bang nhau" << '\n';
    }

    exit(0);
}

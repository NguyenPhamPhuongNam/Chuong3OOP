#ifndef PHANSO_H
#define PHANSO_H

#include <bits/stdc++.h>

class PhanSo {
private:
    int iTu;
    int iMau;


    void rutgon();

public:
//constructor mac dinh
    PhanSo();
//constructor co tham so
    PhanSo(int Tu, int Mau);

    PhanSo operator+(const PhanSo& other);
    PhanSo operator-(const PhanSo& other);
    PhanSo operator*(const PhanSo& other);
    PhanSo operator/(const PhanSo& other);

    bool operator==(const PhanSo& other);
    bool operator!=(const PhanSo& other);
    bool operator>=(const PhanSo& other);
    bool operator<=(const PhanSo& other);
    bool operator>(const PhanSo& other);
    bool operator<(const PhanSo& other);

    // Toan tu nhap xuat
    friend std::istream& operator>>(std::istream& in, PhanSo& ps);
    friend std::ostream& operator<<(std::ostream& out, const PhanSo& ps);
};

#endif 

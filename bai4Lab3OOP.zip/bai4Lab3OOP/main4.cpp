#include <bits/stdc++.h>
#include "NgayThangNam.h"

int main() {
    NgayThangNam ngay1, ngay2;

    std::cout << "Nhap ngay thang nam thu nhat:" << '\n';
    std::cin >> ngay1;
    std::cout << "Nhap ngay thang nam thu hai:" << '\n';
    std::cin >> ngay2;

    std::cout << "Ngay thu nhat: " << ngay1 << '\n';
    std::cout << "Ngay thu hai: " << ngay2 << '\n';


    NgayThangNam ketQuaCong = ngay1 + 10;
    std::cout << "Ngay thu nhat sau khi cong 10 ngay: " << ketQuaCong << '\n';

    NgayThangNam ketQuaTru = ngay2 - 5;
    std::cout << "Ngay thu hai sau khi tru 5 ngay: " << ketQuaTru << '\n';

    int khoangCach = ngay1 - ngay2;
    std::cout << "Khoang cach giua hai ngay la: " << khoangCach << " ngay" << '\n';

    exit(0);
}
